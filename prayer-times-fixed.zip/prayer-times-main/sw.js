/* PrayerTimes service worker. All app-shell URLs are scope-relative so the PWA
   works on custom domains and GitHub Pages project paths (not just domain root). */
const CACHE_NAME = 'prayertimes-v4';
const scopeUrl = new URL(self.registration.scope);
const shellPaths = [
  './', './index.html', './style.css', './script.js', './manifest.json',
  './icons/app-icon.svg', './icons/icon-192.png', './icons/icon-512.png'
];
const SHELL = shellPaths.map(path => new URL(path, scopeUrl).href);

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // One optional/missing asset should not prevent the whole app from installing.
    await Promise.all(SHELL.map(async url => {
      try {
        const response = await fetch(url, { cache: 'reload' });
        if (response.ok) await cache.put(url, response);
      } catch (_) { /* Network may be unavailable during install. */ }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  // Never cache prayer/geocoding API responses: they must be fresh.
  if (url.hostname === 'api.aladhan.com' ||
      url.hostname.endsWith('bigdatacloud.net') ||
      url.hostname.endsWith('open-meteo.com')) {
    event.respondWith(fetch(request).catch(() => new Response(
      JSON.stringify({ error: 'offline' }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }
    )));
    return;
  }

  // Network-first HTML prevents newly deployed versions being trapped behind stale cache.
  if (request.mode === 'navigate' || request.destination === 'document') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok && new URL(response.url).origin === self.location.origin) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(new URL('./index.html', scopeUrl).href, response.clone());
        }
        return response;
      } catch (_) {
        return (await caches.match(request)) || (await caches.match(new URL('./index.html', scopeUrl).href)) || Response.error();
      }
    })());
    return;
  }

  // Cache-first for same-origin app assets, network-first for external CDN assets.
  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      const cached = await caches.match(request);
      if (cached) return cached;
      const response = await fetch(request);
      if (response.ok) {
        const cache = await caches.open(CACHE_NAME);
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    })());
  }
});
